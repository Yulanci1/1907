import asyncio
from bot import main

if name == "main":
asyncio.run(main())